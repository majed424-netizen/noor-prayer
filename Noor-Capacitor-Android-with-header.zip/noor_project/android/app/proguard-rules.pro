# Noor uses small custom native plugins. Keep plugin entry points for release builds.
-keep class com.noor.prayer.** { *; }
