package com.noor.prayer;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "CompassNative")
public class CompassPlugin extends Plugin implements SensorEventListener {
    private SensorManager sensorManager;
    private Sensor rotationSensor;
    private boolean running=false;

    @PluginMethod
    public void start(PluginCall call) {
        sensorManager=(SensorManager)getContext().getSystemService(Context.SENSOR_SERVICE);
        rotationSensor=sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
        if(rotationSensor==null){ call.reject("لا يتوفر مستشعر دوران مناسب في الهاتف"); return; }
        running=true;
        sensorManager.registerListener(this,rotationSensor,SensorManager.SENSOR_DELAY_GAME);
        call.resolve();
    }
    @PluginMethod
    public void stop(PluginCall call){
        stopSensor(); call.resolve();
    }
    private void stopSensor(){if(sensorManager!=null&&running){sensorManager.unregisterListener(this);running=false;}}
    @Override public void onSensorChanged(SensorEvent event){
        if(event.sensor.getType()!=Sensor.TYPE_ROTATION_VECTOR)return;
        float[] R=new float[9], orientation=new float[3];
        SensorManager.getRotationMatrixFromVector(R,event.values);
        int rotation=getActivity().getWindowManager().getDefaultDisplay().getRotation();
        int axisX=SensorManager.AXIS_X, axisY=SensorManager.AXIS_Y;
        if(rotation==1){axisX=SensorManager.AXIS_Y;axisY=SensorManager.AXIS_MINUS_X;}
        else if(rotation==2){axisX=SensorManager.AXIS_MINUS_X;axisY=SensorManager.AXIS_MINUS_Y;}
        else if(rotation==3){axisX=SensorManager.AXIS_MINUS_Y;axisY=SensorManager.AXIS_X;}
        float[] adjusted=new float[9]; SensorManager.remapCoordinateSystem(R,axisX,axisY,adjusted);
        SensorManager.getOrientation(adjusted,orientation);
        double deg=Math.toDegrees(orientation[0]); if(deg<0)deg+=360;
        JSObject o=new JSObject();o.put("heading",deg);notifyListeners("heading",o);
    }
    @Override public void onAccuracyChanged(Sensor sensor,int accuracy){}
    @Override protected void handleOnDestroy(){stopSensor();super.handleOnDestroy();}
}
