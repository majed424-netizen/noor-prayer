package com.noor.prayer;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import androidx.core.app.ActivityCompat;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name="LocationNative")
public class LocationPlugin extends Plugin {
    private static final int REQ=7101;
    private PluginCall pending;
    @PluginMethod public void getCurrentPosition(PluginCall call){
        if(ActivityCompat.checkSelfPermission(getContext(),Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){
            pending=call; ActivityCompat.requestPermissions(getActivity(),new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},REQ); return;
        }
        fetch(call);
    }
    private void fetch(PluginCall call){
        LocationManager lm=(LocationManager)getContext().getSystemService(LocationManager.class);
        try{
            Location best=null; for(String p:lm.getProviders(true)){Location l=lm.getLastKnownLocation(p);if(l!=null&&(best==null||l.getTime()>best.getTime()))best=l;}
            if(best!=null){resolve(call,best);return;}
            Criteria c=new Criteria();c.setAccuracy(Criteria.ACCURACY_FINE);c.setPowerRequirement(Criteria.POWER_MEDIUM);String provider=lm.getBestProvider(c,true);
            if(provider==null){call.reject("لا يوجد مزود موقع متاح");return;}
            lm.requestSingleUpdate(provider,new LocationListener(){public void onLocationChanged(Location l){resolve(call,l);}public void onProviderEnabled(String p){}public void onProviderDisabled(String p){}public void onStatusChanged(String p,int s,Bundle b){}},null);
        }catch(SecurityException e){call.reject("إذن الموقع غير متاح");}
    }
    private void resolve(PluginCall call,Location l){JSObject o=new JSObject();o.put("latitude",l.getLatitude());o.put("longitude",l.getLongitude());call.resolve(o);}
    @Override public void handleRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){super.handleRequestPermissionsResult(requestCode,permissions,grantResults);if(requestCode==REQ&&pending!=null){PluginCall c=pending;pending=null;if(grantResults.length>0&&grantResults[0]==PackageManager.PERMISSION_GRANTED)fetch(c);else c.reject("تم رفض إذن الموقع");}}
}
