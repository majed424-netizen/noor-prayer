package com.noor.prayer;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class PrayerAlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent){
        Intent s=new Intent(context,AdhanService.class).putExtra("name",intent.getStringExtra("name")).putExtra("key",intent.getStringExtra("key"));
        try{context.startForegroundService(s);}catch(Exception e){context.startService(s);}
        PrayerAlarmPlugin.reschedule(context);
    }
}
