package com.noor.prayer;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.IBinder;
import androidx.core.app.NotificationCompat;

public class AdhanService extends Service {
    private static final String CHANNEL="adhan";
    private MediaPlayer player;
    @Override public void onCreate(){super.onCreate();createChannel();}
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        String name=intent!=null?intent.getStringExtra("name"):"الصلاة";String key=intent!=null?intent.getStringExtra("key"):"prayer";
        Notification n=new NotificationCompat.Builder(this,CHANNEL).setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle("نور — حان وقت الصلاة").setContentText(name).setOngoing(true).setCategory(NotificationCompat.CATEGORY_ALARM).build();
        startForeground(9100,n);
        int res=key!=null&&key.equals("fajr")?R.raw.adhan_fajr:R.raw.adhan_normal;
        try{if(player!=null){player.release();player=null;}player=MediaPlayer.create(this,res);if(player!=null){player.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());player.setOnCompletionListener(mp->{stopSelf();});player.start();}}catch(Exception e){stopSelf();}
        return START_NOT_STICKY;
    }
    private void createChannel(){NotificationManager nm=getSystemService(NotificationManager.class);if(Build.VERSION.SDK_INT>=26){NotificationChannel ch=new NotificationChannel(CHANNEL,"أذان نور",NotificationManager.IMPORTANCE_HIGH);ch.setDescription("تنبيهات أوقات الصلاة");nm.createNotificationChannel(ch);}}
    @Override public void onDestroy(){if(player!=null){player.stop();player.release();player=null;}super.onDestroy();}
    @Override public IBinder onBind(Intent intent){return null;}
}
