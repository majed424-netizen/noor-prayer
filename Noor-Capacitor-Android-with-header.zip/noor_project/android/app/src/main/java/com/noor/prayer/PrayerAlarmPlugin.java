package com.noor.prayer;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Calendar;

@CapacitorPlugin(name="PrayerAlarm")
public class PrayerAlarmPlugin extends Plugin {
    private static final String PREF="noor_alarms";
    private static final String ITEMS="items";
    private AlarmManager alarm(){return (AlarmManager)getContext().getSystemService(Context.ALARM_SERVICE);}
    private boolean exactAllowed(){return Build.VERSION.SDK_INT<31 || alarm().canScheduleExactAlarms();}

    @PluginMethod public void schedule(PluginCall call){
        JSArray items=call.getArray("items"); if(items==null){call.reject("لا توجد أوقات للجدولة");return;}
        try{
            cancelInternal();
            getContext().getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putString(ITEMS,items.toString()).apply();
            scheduleJson(new JSONArray(items.toString()));
            JSObject out=new JSObject();
            if(exactAllowed())out.put("message","تمت جدولة تنبيهات الصلاة بواسطة AlarmManager المحلي.");
            else out.put("message","تمت الجدولة ببديل غير دقيق لأن إذن المنبه الدقيق غير متاح. يمكنك تفعيله من إعدادات المنبهات والتذكيرات.");
            call.resolve(out);
        }catch(Exception e){call.reject("فشل جدولة التنبيهات: "+e.getMessage());}
    }
    @PluginMethod public void cancel(PluginCall call){cancelInternal();getContext().getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().remove(ITEMS).apply();call.resolve();}
    @PluginMethod public void requestExactAlarm(PluginCall call){
        if(Build.VERSION.SDK_INT>=31&&!exactAllowed()){try{Intent i=new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:"+getContext().getPackageName()));getActivity().startActivity(i);}catch(Exception ignored){}}call.resolve();
    }
    public static void reschedule(Context c){try{String s=c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString(ITEMS,null);if(s!=null)new PrayerAlarmPlugin().scheduleForReceiver(c,new JSONArray(s));}catch(Exception ignored){}}
    private void scheduleForReceiver(Context c,JSONArray a)throws Exception{cancelFor(c);for(int i=0;i<a.length();i++)scheduleOne(c,a.getJSONObject(i),i);}
    private void scheduleJson(JSONArray a)throws Exception{for(int i=0;i<a.length();i++)scheduleOne(getContext(),a.getJSONObject(i),i);}
    private void scheduleOne(Context c,JSONObject o,int index){
        int h=o.optInt("hour",0),m=o.optInt("minute",0);Calendar cal=Calendar.getInstance();cal.set(Calendar.HOUR_OF_DAY,h);cal.set(Calendar.MINUTE,m);cal.set(Calendar.SECOND,0);cal.set(Calendar.MILLISECOND,0);if(cal.getTimeInMillis()<=System.currentTimeMillis())cal.add(Calendar.DAY_OF_YEAR,1);
        Intent in=new Intent(c,PrayerAlarmReceiver.class).putExtra("name",o.optString("name","الصلاة")).putExtra("key",o.optString("key","prayer"));
        PendingIntent pi=PendingIntent.getBroadcast(c,5000+index,in,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);if(Build.VERSION.SDK_INT>=31&&am.canScheduleExactAlarms())am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,cal.getTimeInMillis(),pi);else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,cal.getTimeInMillis(),pi);
    }
    private void cancelInternal(){cancelFor(getContext());}
    private static void cancelFor(Context c){AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);for(int i=0;i<20;i++){Intent in=new Intent(c,PrayerAlarmReceiver.class);PendingIntent pi=PendingIntent.getBroadcast(c,5000+i,in,PendingIntent.FLAG_NO_CREATE|PendingIntent.FLAG_IMMUTABLE);if(pi!=null){am.cancel(pi);pi.cancel();}}}
}
