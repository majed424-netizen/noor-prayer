البيانات المحلية لتطبيق نور.
quran.json = 114 سورة / 6236 آية.
duas.json = أدعية محلية.
cities.json = مدن وإحداثيات ومناطق زمنية.
schedule-schema.example.json = مثال لاستيراد جدول رسمي محلي.
