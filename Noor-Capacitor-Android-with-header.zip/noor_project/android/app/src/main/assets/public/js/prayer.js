export const RAD=Math.PI/180;
const clamp=(x,a,b)=>Math.min(b,Math.max(a,x));
export function julianDay(date){return date.getTime()/86400000+2440587.5;}
function sunPosition(date){
  const jd=julianDay(date), T=(jd-2451545)/36525;
  const L0=(280.46646+T*(36000.76983+T*0.0003032))%360;
  const M=(357.52911+T*(35999.05029-0.0001537*T))*RAD;
  const e=0.016708634-T*(0.000042037+0.0000001267*T);
  const C=(1.914602-T*(0.004817+0.000014*T))*Math.sin(M)+(0.019993-0.000101*T)*Math.sin(2*M)+0.000289*Math.sin(3*M);
  const trueLong=(L0+C)*RAD;
  const omega=(125.04-1934.136*T)*RAD;
  const lambda=trueLong-0.00569*RAD-0.00478*Math.sin(omega);
  const eps=(23.439291-0.0130042*T)*RAD;
  const decl=Math.asin(Math.sin(eps)*Math.sin(lambda));
  const y=Math.tan(eps/2)**2;
  const eq=4/ RAD*(y*Math.sin(2*L0*RAD)-2*e*Math.sin(M)+4*e*y*Math.sin(M)*Math.cos(2*L0*RAD)-0.5*y*y*Math.sin(4*L0*RAD)-1.25*e*e*Math.sin(2*M));
  return {decl,eq};
}
function tzOffsetMinutes(date,timeZone){
  const p=new Intl.DateTimeFormat('en-US',{timeZone,hour12:false,year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit'}).formatToParts(date);
  const o={}; for(const x of p)o[x.type]=x.value;
  const asUTC=Date.UTC(+o.year,+o.month-1,+o.day,+o.hour,+o.minute,+o.second);
  return Math.round((asUTC-date.getTime())/60000);
}
function localNoonDate(y,m,d,tz){
  const probe=new Date(Date.UTC(y,m-1,d,12));
  const off=tzOffsetMinutes(probe,tz);
  return new Date(Date.UTC(y,m-1,d,12)-off*60000);
}
function hourAngle(lat,dec,alt){
  const x=(Math.sin(alt*RAD)-Math.sin(lat*RAD)*Math.sin(dec))/(Math.cos(lat*RAD)*Math.cos(dec));
  if(x<=-1)return 180;if(x>=1)return NaN;return Math.acos(x)/RAD;
}
function asrAngle(lat,dec,factor){const shadow=factor+Math.tan(Math.abs(lat*RAD-dec));return Math.atan(1/shadow)/RAD;}
export const METHODS={
 pal:{name:'الحساب المحلي الفلسطيني',fajr:18,isha:17,asr:1,offsets:[0,-1,0,1,0,0]},
 mwl:{name:'رابطة العالم الإسلامي',fajr:18,isha:17,asr:1,offsets:[0,0,0,0,0,0]},
 eg:{name:'الهيئة المصرية',fajr:19.5,isha:17.5,asr:1,offsets:[0,0,0,0,0,0]},
 umm:{name:'أم القرى',fajr:18.5,isha:90,asr:1,offsets:[0,0,0,0,0,0],ishaMinutes:true}
};
function formatParts(y,m,d,min,tz){
  let dayShift=0; while(min<0){min+=1440;dayShift--} while(min>=1440){min-=1440;dayShift++}
  const utc=localNoonDate(y,m,d,tz); const dt=new Date(utc.getTime()+(min-720)*60000+dayShift*86400000);
  const parts=new Intl.DateTimeFormat('en-CA',{timeZone:tz,year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hour12:false}).formatToParts(dt); const o={}; for(const p of parts)o[p.type]=p.value;
  return {minutes:min, hour:+o.hour===24?0:+o.hour, minute:+o.minute, date:dt};
}
export function calculatePrayerTimes({date=new Date(),lat,lon,timeZone,method='pal'}){
  const m=METHODS[method]||METHODS.pal; const y=+new Intl.DateTimeFormat('en-US',{timeZone,year:'numeric'}).format(date), mo=+new Intl.DateTimeFormat('en-US',{timeZone,month:'numeric'}).format(date), da=+new Intl.DateTimeFormat('en-US',{timeZone,day:'numeric'}).format(date);
  const noonDate=localNoonDate(y,mo,da,timeZone), s=sunPosition(noonDate), off=tzOffsetMinutes(noonDate,timeZone);
  const noon=720-4*lon-s.eq+off;
  const riseHA=hourAngle(lat,s.decl,-0.833), fajrHA=hourAngle(lat,s.decl,-m.fajr), asrHA=hourAngle(lat,s.decl,asrAngle(lat,s.decl,m.asr)), ishaHA=hourAngle(lat,s.decl,-(m.ishaMinutes?0.833:m.isha));
  const vals={fajr:noon-4*fajrHA,sunrise:noon-4*riseHA,dhuhr:noon,asr:noon+4*asrHA,sunset:noon+4*riseHA,maghrib:noon+4*riseHA,isha:m.ishaMinutes?noon+4*riseHA+m.isha:noon+4*ishaHA};
  const keys=['fajr','sunrise','dhuhr','asr','maghrib','isha'];
  const out={}; for(const k of keys){const idx=keys.indexOf(k);let v=vals[k]+(m.offsets[idx]||0);out[k]=formatParts(y,mo,da,v,timeZone)}
  out.date={year:y,month:mo,day:da};out.method=m.name;out.timeZone=timeZone;return out;
}
export function qiblaBearing(lat,lon){const φ1=lat*RAD,φ2=21.4225*RAD,dl=(39.8262-lon)*RAD;const y=Math.sin(dl),x=Math.cos(φ1)*Math.tan(φ2)-Math.sin(φ1)*Math.cos(dl);return (Math.atan2(y,x)/RAD+360)%360;}
export function qiblaDistanceKm(lat,lon){const R=6371,a=lat*RAD,b=lon*RAD,c=21.4225*RAD,d=39.8262*RAD;const x=Math.sin((c-a)/2)**2+Math.cos(a)*Math.cos(c)*Math.sin((d-b)/2)**2;return 2*R*Math.asin(Math.sqrt(x));}
export function localMinutesForTime(t){return t.hour*60+t.minute}
