import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const q=JSON.parse(fs.readFileSync(new URL('../www/data/quran.json',import.meta.url),'utf8'));
test('Quran has 114 surahs and 6236 verses',()=>{assert.equal(q.surahs.length,114);assert.equal(q.surahs.reduce((n,s)=>n+s.verses.length,0),6236)});
test('First and last verses are present',()=>{assert.ok(q.surahs[0].verses[0].text.length>5);assert.ok(q.surahs[113].verses.at(-1).text.length>5)});
test('All ayah numbers restart at one per surah',()=>{for(const s of q.surahs)assert.equal(s.verses[0].number,1)});
