import test from 'node:test';
import assert from 'node:assert/strict';
import {qiblaBearing,qiblaDistanceKm,calculatePrayerTimes} from '../www/js/prayer.js';

test('Qibla bearing Jenin is near expected range',()=>{const b=qiblaBearing(32.461,35.301);assert.ok(b>155&&b<163,`bearing=${b}`)});
test('Qibla bearing Aqsa is near expected range',()=>{const b=qiblaBearing(31.778,35.2354);assert.ok(b>153&&b<161,`bearing=${b}`)});
test('Qibla distance is positive',()=>assert.ok(qiblaDistanceKm(32.461,35.301)>100));
test('Prayer times are ordered for Jenin',()=>{const t=calculatePrayerTimes({date:new Date('2026-11-08T12:00:00Z'),lat:32.461,lon:35.301,timeZone:'Asia/Hebron',method:'pal'});const a=['fajr','sunrise','dhuhr','asr','maghrib','isha'].map(k=>t[k].hour*60+t[k].minute);for(let i=1;i<a.length;i++)assert.ok(a[i]>a[i-1],`${i}: ${a}`)});
test('Prayer calculation supports Jerusalem timezone',()=>{const t=calculatePrayerTimes({date:new Date('2026-06-01T12:00:00Z'),lat:31.7683,lon:35.2137,timeZone:'Asia/Jerusalem',method:'mwl'});assert.equal(t.timeZone,'Asia/Jerusalem');assert.ok(t.fajr.hour>=0&&t.fajr.hour<12)});
